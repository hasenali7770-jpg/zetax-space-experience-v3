$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot

if (-not (Get-Command node -ErrorAction SilentlyContinue)) {
    Write-Host 'Node.js غير مثبت أو غير مضاف إلى PATH.' -ForegroundColor Red
    Read-Host 'اضغط Enter للخروج'
    exit 1
}

if (-not (Test-Path (Join-Path $PSScriptRoot 'server.js'))) {
    Write-Host 'ملف server.js غير موجود في هذا المجلد.' -ForegroundColor Red
    Read-Host 'اضغط Enter للخروج'
    exit 1
}

$portFile = Join-Path $PSScriptRoot '.zetax-port'
Remove-Item $portFile -ErrorAction SilentlyContinue
Start-Job -ScriptBlock {
    param($File)
    for ($i = 0; $i -lt 80; $i++) {
        if (Test-Path $File) {
            $port = (Get-Content $File -Raw).Trim()
            Start-Process "http://localhost:$port"
            break
        }
        Start-Sleep -Milliseconds 250
    }
} -ArgumentList $portFile | Out-Null

node (Join-Path $PSScriptRoot 'server.js')
