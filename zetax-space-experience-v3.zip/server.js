const http = require('http');
const fs = require('fs');
const path = require('path');
const zlib = require('zlib');

const root = __dirname;
let port = Number(process.env.PORT || 3000);
const mime = {
  '.html':'text/html; charset=utf-8', '.css':'text/css; charset=utf-8', '.js':'application/javascript; charset=utf-8',
  '.json':'application/json; charset=utf-8', '.png':'image/png', '.jpg':'image/jpeg', '.jpeg':'image/jpeg', '.svg':'image/svg+xml',
  '.ico':'image/x-icon', '.webp':'image/webp', '.woff2':'font/woff2'
};
const compressible = new Set(['.html','.css','.js','.json','.svg']);

function resolveUrl(url) {
  const clean = decodeURIComponent(url.split('?')[0]);
  if (clean === '/') return '/apps/site/index.html';
  if (clean === '/employee' || clean === '/employee/') return '/apps/employee/index.html';
  if (clean === '/customer' || clean === '/customer/') return '/apps/customer/index.html';
  return clean;
}

const server = http.createServer((req, res) => {
  const rel = resolveUrl(req.url);
  const file = path.normalize(path.join(root, rel));
  if (!file.startsWith(root)) { res.writeHead(403); return res.end('Forbidden'); }
  fs.stat(file, (err, stat) => {
    if (err || !stat.isFile()) { res.writeHead(404, {'Content-Type':'text/plain; charset=utf-8'}); return res.end('Not found'); }
    const ext = path.extname(file).toLowerCase();
    const isHtml = ext === '.html';
    const headers = {
      'Content-Type': mime[ext] || 'application/octet-stream',
      'Cache-Control': isHtml ? 'no-cache' : 'public, max-age=3600',
      'Vary': 'Accept-Encoding',
      'X-Content-Type-Options': 'nosniff'
    };
    const acceptsGzip = /gzip/.test(req.headers['accept-encoding'] || '') && compressible.has(ext);
    if (acceptsGzip) headers['Content-Encoding'] = 'gzip';
    res.writeHead(200, headers);
    const stream = fs.createReadStream(file);
    if (acceptsGzip) stream.pipe(zlib.createGzip({level: 6})).pipe(res); else stream.pipe(res);
  });
});

function startServer() {
  server.listen(port, '0.0.0.0');
}
server.on('error', (error) => {
  if (error.code === 'EADDRINUSE' && !process.env.PORT && port < 3010) {
    console.log(`  Port ${port} is busy. Trying ${port + 1}...`);
    port += 1;
    setTimeout(startServer, 120);
    return;
  }
  throw error;
});
server.on('listening', () => {
  try { fs.writeFileSync(path.join(root, '.zetax-port'), String(port)); } catch (_) {}
  console.log('\n  ZETAX SPACE EXPERIENCE V3');
  console.log('  Optimized loading + languages + themes + customer login + CRM/support');
  console.log(`  Website:  http://localhost:${port}`);
  console.log(`  Employee: http://localhost:${port}/employee`);
  console.log(`  Customer: http://localhost:${port}/customer\n`);
});
startServer();
