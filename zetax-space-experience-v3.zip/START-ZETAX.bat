@echo off
chcp 65001 > nul
title Zetax Space Experience V3
cd /d "%~dp0"

where node >nul 2>nul
if errorlevel 1 (
  echo.
  echo [ERROR] Node.js غير مثبت أو غير مضاف إلى PATH.
  echo ثبّت Node.js ثم أعد المحاولة.
  echo.
  pause
  exit /b 1
)

if not exist "%~dp0server.js" (
  echo.
  echo [ERROR] ملف server.js غير موجود داخل هذا المجلد.
  echo تأكد من فك الضغط بالكامل ثم شغّل الملف من المجلد نفسه.
  echo.
  pause
  exit /b 1
)

if exist "%~dp0.zetax-port" del /q "%~dp0.zetax-port"
start "" powershell -NoProfile -WindowStyle Hidden -Command "$p='%~dp0.zetax-port'; for($i=0;$i -lt 80;$i++){if(Test-Path $p){$port=(Get-Content $p -Raw).Trim(); Start-Process ('http://localhost:'+$port); break}; Start-Sleep -Milliseconds 250}"
node "%~dp0server.js"

echo.
echo تم إيقاف خادم Zetax Space.
pause
