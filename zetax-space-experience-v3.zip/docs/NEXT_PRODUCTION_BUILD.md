# المرحلة الإنتاجية التالية

- تحويل الواجهة إلى Next.js + TypeScript.
- Backend باستخدام NestJS.
- PostgreSQL وRedis.
- تسجيل دخول وصلاحيات RBAC و2FA.
- OpenAI Responses API عبر Backend فقط.
- رفع ملفات إلى S3 compatible storage.
- WebSocket للمحادثة والإشعارات.
- إنشاء عروض الأسعار والفواتير بموافقة بشرية.
- بوابات الدفع والدومينات والاستضافة.
- اختبارات أمان وأداء وإتاحة.
