(()=>{
  'use strict';
  const qs=s=>document.querySelector(s);
  const session=JSON.parse(localStorage.getItem('zetax_customer_session')||'null')||{name:'عميل Zetax',email:'client@zetax.space',company:'حساب شركة'};
  const name=session.name||'عميل Zetax',email=session.email||session.company||'حساب شركة';
  qs('#customerName').textContent=name;qs('#customerEmail').textContent=email;qs('#customerInitial').textContent=name.trim().charAt(0).toUpperCase();
  const setTheme=t=>{document.documentElement.dataset.theme=t;localStorage.setItem('zetax_theme',t);qs('#customerTheme').textContent=t==='dark'?'☀':'☾'};
  setTheme(localStorage.getItem('zetax_theme')||'dark');
  qs('#customerTheme').addEventListener('click',()=>setTheme(document.documentElement.dataset.theme==='dark'?'light':'dark'));
  qs('#logoutBtn').addEventListener('click',()=>{localStorage.removeItem('zetax_customer_session');location.href='/'});
  const io=new IntersectionObserver(es=>es.forEach(e=>{if(e.isIntersecting){e.target.classList.add('show');io.unobserve(e.target)}}),{threshold:.08});document.querySelectorAll('.reveal').forEach(e=>io.observe(e));
})();
