(() => {
  'use strict';
  const qs=(s,r=document)=>r.querySelector(s);
  const qsa=(s,r=document)=>[...r.querySelectorAll(s)];
  const finePointer=matchMedia('(pointer:fine)').matches;
  const reducedMotion=matchMedia('(prefers-reduced-motion: reduce)').matches;
  const lowPower=innerWidth<760 || (navigator.hardwareConcurrency && navigator.hardwareConcurrency<=4);
  if(lowPower) document.documentElement.classList.add('performance-lite');

  /* Theme */
  const savedTheme=localStorage.getItem('zetax_theme') || (matchMedia('(prefers-color-scheme: light)').matches?'light':'dark');
  const setTheme=(theme)=>{
    document.documentElement.dataset.theme=theme;
    localStorage.setItem('zetax_theme',theme);
    const b=qs('#themeBtn'); if(b){b.textContent=theme==='dark'?'☀':'☾';b.title=theme==='dark'?'تفعيل الوضع الفاتح':'تفعيل الوضع الداكن'}
  };
  setTheme(savedTheme);
  qs('#themeBtn')?.addEventListener('click',()=>setTheme(document.documentElement.dataset.theme==='dark'?'light':'dark'));

  /* Professional, fast intro. It only plays fully once per browser session. */
  const loader=qs('#loader'),lp=qs('#loaderProgress'),lt=qs('#loaderText');
  const introSeen=sessionStorage.getItem('zetax_intro_seen');
  const start=performance.now(), duration=introSeen?180:(reducedMotion?300:900);
  function introFrame(now){
    const p=Math.min(1,(now-start)/duration), eased=1-Math.pow(1-p,3), value=Math.round(eased*100);
    if(lp) lp.style.width=value+'%'; if(lt) lt.textContent=`تشغيل Zetax Digital Core… ${value}%`;
    if(p<1) requestAnimationFrame(introFrame); else {sessionStorage.setItem('zetax_intro_seen','1');setTimeout(()=>loader?.classList.add('hide'),70)}
  }
  requestAnimationFrame(introFrame);

  /* Cursor and magnetic interactions only on desktop */
  const dot=qs('.cursor-dot'),ring=qs('.cursor-ring');
  if(finePointer && !reducedMotion && dot && ring){
    let mx=0,my=0,rx=0,ry=0,raf=0;
    addEventListener('mousemove',e=>{mx=e.clientX;my=e.clientY;dot.style.transform=`translate(${mx}px,${my}px) translate(-50%,-50%)`;if(!raf)raf=requestAnimationFrame(loop)});
    function loop(){rx+=(mx-rx)*.16;ry+=(my-ry)*.16;ring.style.transform=`translate(${rx}px,${ry}px) translate(-50%,-50%)`;raf=requestAnimationFrame(loop)}
    qsa('a,button,input,textarea,.service-card').forEach(el=>{el.addEventListener('mouseenter',()=>ring.classList.add('active'));el.addEventListener('mouseleave',()=>ring.classList.remove('active'))});
    qsa('.magnetic').forEach(el=>{el.addEventListener('mousemove',e=>{const r=el.getBoundingClientRect();el.style.transform=`translate(${(e.clientX-r.left-r.width/2)*.1}px,${(e.clientY-r.top-r.height/2)*.1}px)`});el.addEventListener('mouseleave',()=>el.style.transform='')});
  }

  /* Navbar and menus */
  const nav=qs('#nav'),menu=qs('#mobileMenu'),langMenu=qs('#langMenu'),langBtn=qs('#langBtn');
  addEventListener('scroll',()=>nav?.classList.toggle('scrolled',scrollY>40),{passive:true});
  qs('#menuBtn')?.addEventListener('click',()=>menu?.classList.toggle('open'));
  qsa('#mobileMenu a').forEach(a=>a.addEventListener('click',()=>menu?.classList.remove('open')));
  langBtn?.addEventListener('click',e=>{e.stopPropagation();const open=langMenu.classList.toggle('open');langBtn.setAttribute('aria-expanded',String(open))});
  document.addEventListener('click',()=>{langMenu?.classList.remove('open');langBtn?.setAttribute('aria-expanded','false')});

  /* Real language switcher for the primary customer journey */
  const languages={
    ar:{code:'AR',dir:'rtl',titlePrefix:'نحوّل فكرتك إلى',words:['منتج عالمي','منصة ذكية','تجربة لا تُنسى','شركة قابلة للتوسع'],lead:'Zetax Space تجمع البرمجة، الاستضافة، الدومينات، القوالب، أنظمة الشركات والذكاء الاصطناعي داخل تجربة واحدة ذكية وسريعة.',status:'منظومة رقمية تُبنى من العراق إلى العالم',prompt:'مثال: أريد تطبيق مطعم مع كاشير وتوصيل وتتبع للسائق…',login:'تسجيل الدخول',start:'ابدأ مشروعك',nav:['التجربة','الخدمات','Zetax AI','القوالب','تواصل']},
    en:{code:'EN',dir:'ltr',titlePrefix:'We turn your idea into a',words:['global product','smart platform','memorable experience','scalable company'],lead:'Zetax Space brings software, hosting, domains, templates, business systems and AI into one fast intelligent experience.',status:'A digital ecosystem built in Iraq for the world',prompt:'Example: I need a restaurant app with POS, delivery and driver tracking…',login:'Sign in',start:'Start your project',nav:['Experience','Services','Zetax AI','Templates','Contact']},
    ku:{code:'KU',dir:'rtl',titlePrefix:'بیرۆکەکەت دەگۆڕین بۆ',words:['بەرهەمێکی جیهانی','پلاتفۆرمێکی زیرەک','ئەزموونێکی تایبەت','کۆمپانیایەکی گەشەپێدراو'],lead:'Zetax Space بەرنامەسازی، هۆستینگ، دۆمەین، قاڵب، سیستەمی بازرگانی و زیرەکی دەستکرد لە یەک ئەزموونی خێرا کۆدەکاتەوە.',status:'سیستەمێکی دیجیتاڵ لە عێراقەوە بۆ جیهان',prompt:'نموونە: ئەپێکی چێشتخانە لەگەڵ POS و گەیاندن…',login:'چوونەژوورەوە',start:'پڕۆژەکەت دەستپێبکە',nav:['ئەزموون','خزمەتگوزاری','Zetax AI','قاڵبەکان','پەیوەندی']}
  };
  let currentLang=localStorage.getItem('zetax_lang')||'ar',rotatingWords=languages[currentLang].words,wordIndex=0;
  function setText(selector,text){const e=qs(selector);if(e)e.textContent=text}
  function applyLanguage(lang){
    currentLang=languages[lang]?lang:'ar';const t=languages[currentLang];localStorage.setItem('zetax_lang',currentLang);document.documentElement.lang=currentLang;document.documentElement.dir=t.dir;langBtn.textContent=t.code;
    qsa('.nav-links a').forEach((a,i)=>{if(t.nav[i])a.textContent=t.nav[i]});
    qsa('#mobileMenu a').slice(0,3).forEach((a,i)=>{if(t.nav[i])a.textContent=t.nav[i]});
    setText('#openLogin',t.login);setText('#mobileLogin',t.login);qsa('[data-open-chat]').forEach((b,i)=>{const s=b.querySelector('span');if(i===2){const txt=b.querySelector('span');if(txt)txt.textContent=t.start}else{b.childNodes[0].textContent=t.start+' ';if(s&&s.textContent!=='↗')s.textContent=t.start}});
    const status=qs('.status-pill');if(status)status.innerHTML=`<span class="online-dot"></span> ${t.status}`;
    setText('.hero-title span',t.titlePrefix);setText('#rotatingWord',t.words[0]);rotatingWords=t.words;wordIndex=0;setText('.hero-lead',t.lead);const hi=qs('#heroInput');if(hi)hi.placeholder=t.prompt;
  }
  qsa('#langMenu [data-lang]').forEach(b=>b.addEventListener('click',e=>{e.stopPropagation();applyLanguage(b.dataset.lang);langMenu.classList.remove('open')}));
  applyLanguage(currentLang);

  /* Reveal */
  const revealObserver=new IntersectionObserver(entries=>entries.forEach(e=>{if(e.isIntersecting){e.target.classList.add('show');revealObserver.unobserve(e.target)}}),{threshold:.08,rootMargin:'0px 0px -25px'});
  qsa('.reveal').forEach(el=>revealObserver.observe(el));

  /* Rotating title */
  if(!reducedMotion)setInterval(()=>{const w=qs('#rotatingWord');if(!w||document.hidden)return;w.animate([{opacity:1,transform:'translateY(0)'},{opacity:0,transform:'translateY(-13px)'}],{duration:260,fill:'forwards'}).onfinish=()=>{w.textContent=rotatingWords[++wordIndex%rotatingWords.length];w.animate([{opacity:0,transform:'translateY(13px)'},{opacity:1,transform:'translateY(0)'}],{duration:320,fill:'forwards'})}},2900);

  /* Prompt */
  const heroInput=qs('#heroInput');
  heroInput?.addEventListener('input',()=>{heroInput.style.height='auto';heroInput.style.height=Math.min(125,heroInput.scrollHeight)+'px'});
  qsa('.prompt-suggestions button').forEach(b=>b.addEventListener('click',()=>{heroInput.value=`أريد ${b.textContent} احترافي مع لوحة تحكم وذكاء اصطناعي`;heroInput.dispatchEvent(new Event('input'));heroInput.focus()}));

  /* Optimized interactive core: pauses off-screen and while the tab is hidden */
  const canvas=qs('#coreCanvas');
  if(canvas){
    const ctx=canvas.getContext('2d',{alpha:true}),parent=canvas.parentElement;let w=0,h=0,visible=true,running=true,pointer={x:.5,y:.5};
    const dpr=Math.min(devicePixelRatio||1,lowPower?1:1.45),count=lowPower?42:78;
    const points=Array.from({length:count},(_,i)=>{const phi=Math.acos(1-2*(i+.5)/count),theta=Math.PI*(1+Math.sqrt(5))*i;return{phi,theta,phase:Math.random()*6.28,size:.8+Math.random()*1.35}});
    function resize(){const r=canvas.getBoundingClientRect();w=r.width;h=r.height;canvas.width=Math.max(1,Math.round(w*dpr));canvas.height=Math.max(1,Math.round(h*dpr));ctx.setTransform(dpr,0,0,dpr,0,0)}resize();addEventListener('resize',resize,{passive:true});
    parent.addEventListener('pointermove',e=>{const r=canvas.getBoundingClientRect();pointer.x=(e.clientX-r.left)/r.width;pointer.y=(e.clientY-r.top)/r.height},{passive:true});
    new IntersectionObserver(es=>{visible=es[0].isIntersecting},{rootMargin:'120px'}).observe(parent);
    document.addEventListener('visibilitychange',()=>running=!document.hidden);
    function draw(t){
      if(visible&&running){ctx.clearRect(0,0,w,h);const cx=w*.5,cy=h*.48,rad=Math.min(w,h)*.29,rot=t*.00016+(pointer.x-.5)*.55,tilt=(pointer.y-.5)*.38,projected=[];
        for(let i=0;i<points.length;i++){const p=points[i],wave=1+.045*Math.sin(t*.0013+p.phase),sx=Math.sin(p.phi)*Math.cos(p.theta+rot),sy=Math.cos(p.phi),sz=Math.sin(p.phi)*Math.sin(p.theta+rot),y2=sy*Math.cos(tilt)-sz*Math.sin(tilt),z2=sy*Math.sin(tilt)+sz*Math.cos(tilt),scale=1/(1.82-z2*.42);projected.push({x:cx+sx*rad*wave*scale,y:cy+y2*rad*wave*scale,z:z2,s:scale,size:p.size,i})}
        projected.sort((a,b)=>a.z-b.z);ctx.globalCompositeOperation='lighter';ctx.lineWidth=.45;
        for(let i=0;i<projected.length;i+=4){const a=projected[i];for(let j=i+1;j<Math.min(i+6,projected.length);j++){const b=projected[j],dist=Math.hypot(a.x-b.x,a.y-b.y);if(dist<78){ctx.strokeStyle=`rgba(103,119,255,${(1-dist/78)*.13})`;ctx.beginPath();ctx.moveTo(a.x,a.y);ctx.lineTo(b.x,b.y);ctx.stroke()}}}
        projected.forEach((p,i)=>{const rgb=i%3===0?'43,218,231':i%3===1?'121,91,255':'205,63,255';ctx.fillStyle=`rgba(${rgb},${.32+(p.z+1)*.15})`;ctx.beginPath();ctx.arc(p.x,p.y,p.size*p.s,0,Math.PI*2);ctx.fill()});ctx.globalCompositeOperation='source-over';
        ctx.save();ctx.translate(cx,cy);ctx.rotate(-t*.0001);for(let i=0;i<2;i++){ctx.strokeStyle=`rgba(${i?'139,69,255':'43,218,231'},${.12+i*.035})`;ctx.lineWidth=1;ctx.setLineDash([8+i*3,15]);ctx.beginPath();ctx.ellipse(0,0,rad*(1.3+i*.18),rad*(.45+i*.07),i*.7,0,Math.PI*2);ctx.stroke()}ctx.restore();
      }
      requestAnimationFrame(draw)
    }requestAnimationFrame(draw);
  }

  /* Lightweight service particles, only while visible */
  qsa('.service-card').forEach((card,idx)=>{
    const c=qs('canvas',card);if(!c)return;const x=c.getContext('2d');let w=0,h=0,active=false;const dpr=Math.min(devicePixelRatio||1,1.25),colors=['32,219,229','147,69,255','47,114,255','220,55,255','53,225,161','255,200,87'],particles=Array.from({length:lowPower?5:9},()=>({x:Math.random(),y:Math.random(),r:1+Math.random()*1.4,v:.00014+Math.random()*.0002}));
    function resize(){const r=c.getBoundingClientRect();w=r.width;h=r.height;c.width=w*dpr;c.height=h*dpr;x.setTransform(dpr,0,0,dpr,0,0)}resize();
    new IntersectionObserver(es=>active=es[0].isIntersecting,{rootMargin:'80px'}).observe(card);
    function draw(t){if(active&&!document.hidden){x.clearRect(0,0,w,h);particles.forEach(p=>{p.y-=p.v*16;if(p.y<0)p.y=1;x.fillStyle=`rgba(${colors[idx]},${.12+.13*Math.sin(t*.001+p.x*6)})`;x.beginPath();x.arc(p.x*w,p.y*h,p.r,0,7);x.fill()})}requestAnimationFrame(draw)}requestAnimationFrame(draw);
    if(finePointer&&!reducedMotion){card.addEventListener('mousemove',e=>{const r=card.getBoundingClientRect(),px=(e.clientX-r.left)/r.width-.5,py=(e.clientY-r.top)/r.height-.5;card.style.transform=`perspective(900px) rotateY(${px*4}deg) rotateX(${-py*4}deg) translateY(-6px)`});card.addEventListener('mouseleave',()=>card.style.transform='')}
  });

  /* Project track */
  const track=qs('#projectTrack');if(track){let down=false,sx=0,sl=0;track.addEventListener('pointerdown',e=>{down=true;sx=e.clientX;sl=track.scrollLeft;track.setPointerCapture(e.pointerId)});track.addEventListener('pointermove',e=>{if(down)track.scrollLeft=sl-(e.clientX-sx)});track.addEventListener('pointerup',()=>down=false);track.addEventListener('wheel',e=>{if(Math.abs(e.deltaY)>Math.abs(e.deltaX)){track.scrollLeft+=e.deltaY;e.preventDefault()}},{passive:false})}

  /* Dialog helpers */
  const openDialog=id=>{const d=qs('#'+id);if(d&&!d.open)d.showModal()};
  qsa('[data-close]').forEach(b=>b.addEventListener('click',()=>qs('#'+b.dataset.close)?.close()));
  qsa('[data-open-chat]').forEach(b=>b.addEventListener('click',()=>openDialog('chatDialog')));
  qs('#openLogin')?.addEventListener('click',()=>{const session=JSON.parse(localStorage.getItem('zetax_customer_session')||'null');session?location.href='/customer':openDialog('loginDialog')});
  qs('#mobileLogin')?.addEventListener('click',()=>{menu?.classList.remove('open');openDialog('loginDialog')});
  qs('#attachBtn')?.addEventListener('click',()=>openDialog('chatDialog'));

  /* Customer login -> direct customer dashboard */
  const loginForm=qs('#loginForm'),email=qs('#loginEmail'),password=qs('#loginPassword'),loginStatus=qs('#loginStatus');
  qs('#togglePassword')?.addEventListener('click',e=>{const show=password.type==='password';password.type=show?'text':'password';e.currentTarget.textContent=show?'إخفاء':'إظهار'});
  loginForm?.addEventListener('submit',e=>{e.preventDefault();const mail=email.value.trim(),pass=password.value;if(!/^\S+@\S+\.\S+$/.test(mail)||pass.length<4){loginStatus.textContent='تحقق من البريد وكلمة المرور.';loginStatus.className='login-status error';return}if(pass!=='2026'){loginStatus.textContent='كلمة مرور النسخة التجريبية هي 2026.';loginStatus.className='login-status error';return}const name=mail.split('@')[0].replace(/[._-]+/g,' ').replace(/\b\w/g,c=>c.toUpperCase());localStorage.setItem('zetax_customer_session',JSON.stringify({email:mail,name:name||'Zetax Client',company:'حساب شركة',loggedInAt:new Date().toISOString()}));loginStatus.textContent='تم تسجيل الدخول — جاري فتح لوحة العميل…';loginStatus.className='login-status success';setTimeout(()=>location.href='/customer',520)});
  qs('#loginWithOtp')?.addEventListener('click',()=>{qs('#loginDialog')?.close();openDialog('otpDialog');setTimeout(()=>qs('.otp-inputs input')?.focus(),100)});

  /* Requirements chat */
  const messages=qs('#messages'),form=qs('#chatForm'),input=qs('#chatInput'),options=qs('#quickOptions'),result=qs('#resultBox'),json=qs('#jsonResult'),bar=qs('#chatProgress'),percent=qs('#chatPercent');
  const questions=[
    {key:'projectType',text:'أهلاً بك في Zetax Space. شنو نوع المشروع الذي تريد تنفيذه؟',options:['موقع إلكتروني','تطبيق هاتف','متجر إلكتروني','نظام مطعم وPOS','نظام شركة وCRM','استضافة ودومين','مشروع مخصص']},
    {key:'businessName',text:'ممتاز. ما اسم المشروع أو النشاط التجاري؟'},
    {key:'description',text:'صف لي طبيعة العمل والهدف الرئيسي من المشروع.'},
    {key:'features',text:'ما أهم الخصائص المطلوبة؟ اكتبها أو اختر أمثلة مناسبة.',options:['تسجيل مستخدمين','دفع إلكتروني','لوحة تحكم','توصيل وتتبع','ذكاء اصطناعي','فروع متعددة']},
    {key:'platforms',text:'ما المنصات التي تريدها؟',options:['Web','Android','iOS','Web + Android + iOS','غير محدد']},
    {key:'languages',text:'ما اللغات المطلوبة؟',options:['العربية','العربية والإنجليزية','العربية والإنجليزية والكردية']},
    {key:'budget',text:'ما الميزانية التقريبية؟',options:['أقل من $1,000','$1,000 - $3,000','$3,000 - $8,000','$8,000 فأكثر','أحتاج تقديراً']},
    {key:'deadline',text:'هل يوجد موعد مستهدف للإطلاق؟'},
    {key:'customerName',text:'ما اسم مسؤول التواصل؟'},
    {key:'contact',text:'أدخل البريد الإلكتروني أو رقم الهاتف للتواصل.'}
  ];
  let chatState={index:0,answers:{},started:false};
  function addMessage(text,type){if(!messages)return;const d=document.createElement('div');d.className='msg '+type;d.textContent=text;messages.appendChild(d);messages.scrollTop=messages.scrollHeight}
  function updateProgress(){const p=Math.round(chatState.index/questions.length*100);if(bar)bar.style.width=p+'%';if(percent)percent.textContent=p+'%';if(p>20)qs('#sideStep2')?.classList.add('done');if(p>45)qs('#sideStep3')?.classList.add('done');if(p>75)qs('#sideStep4')?.classList.add('done')}
  function renderOptions(list=[]){if(!options)return;options.innerHTML='';list.forEach(v=>{const b=document.createElement('button');b.type='button';b.textContent=v;b.addEventListener('click',()=>submitAnswer(v));options.appendChild(b)})}
  function ask(){const q=questions[chatState.index];if(!q)return finish();setTimeout(()=>{addMessage(q.text,'ai');renderOptions(q.options);input?.focus();updateProgress()},150)}
  function submitAnswer(value){const val=String(value||'').trim();if(!val)return;if(!chatState.started){chatState.started=true;messages.innerHTML='';chatState.index=0;chatState.answers={};addMessage(val,'user');chatState.answers.description=val;chatState.index=1;ask();return}const q=questions[chatState.index];chatState.answers[q.key]=val;addMessage(val,'user');if(input)input.value='';renderOptions();chatState.index++;ask()}
  function finish(){const a=chatState.answers,lead={id:'ZX-'+Date.now().toString().slice(-7),createdAt:new Date().toISOString(),status:'new',source:'Zetax AI Experience V3',customer:{name:a.customerName||'غير مكتمل',contact:a.contact||'غير مكتمل',preferredLanguage:currentLang},project:{name:a.businessName||'مشروع جديد',type:a.projectType||'مخصص',description:a.description||'',platforms:a.platforms||'غير محدد',languages:a.languages||'العربية',deadline:a.deadline||'غير محدد'},features:String(a.features||'').split(/[،,]/).map(v=>v.trim()).filter(Boolean),budget:a.budget||'يحتاج تقديراً',requiresHumanReview:true,humanApprovalBeforeQuote:true,aiCostUsd:0,stage:'requirements-complete'};const leads=JSON.parse(localStorage.getItem('zetax_leads')||'[]');leads.unshift(lead);localStorage.setItem('zetax_leads',JSON.stringify(leads.slice(0,100)));addMessage('تم تجهيز ملف المشروع وإرساله إلى لوحة الموظفين. السعر النهائي لا يُرسل إلا بعد مراجعة بشرية.','ai');if(json)json.textContent=JSON.stringify(lead,null,2);result?.classList.add('show');if(input)input.disabled=true;form?.querySelector('[type=submit]')?.setAttribute('disabled','disabled');chatState.index=questions.length;updateProgress()}
  form?.addEventListener('submit',e=>{e.preventDefault();submitAnswer(input.value)});
  qs('#heroForm')?.addEventListener('submit',e=>{e.preventDefault();openDialog('chatDialog');const value=heroInput.value.trim();if(value){setTimeout(()=>submitAnswer(value),100);heroInput.value=''}});
  if(messages)ask();

  /* Liquid OTP */
  const otpInputs=qsa('.otp-inputs input');
  otpInputs.forEach((inp,i)=>{inp.addEventListener('input',()=>{inp.value=inp.value.replace(/\D/g,'').slice(0,1);inp.parentElement.classList.toggle('filled',!!inp.value);if(inp.value&&otpInputs[i+1])otpInputs[i+1].focus()});inp.addEventListener('keydown',e=>{if(e.key==='Backspace'&&!inp.value&&otpInputs[i-1])otpInputs[i-1].focus()});inp.addEventListener('paste',e=>{const txt=(e.clipboardData.getData('text')||'').replace(/\D/g,'').slice(0,4);if(txt){e.preventDefault();txt.split('').forEach((v,k)=>{if(otpInputs[k]){otpInputs[k].value=v;otpInputs[k].parentElement.classList.add('filled')}});otpInputs[Math.min(txt.length,4)-1].focus()}})});
  qs('#verifyOtp')?.addEventListener('click',()=>{const code=otpInputs.map(i=>i.value).join(''),status=qs('#otpStatus');qsa('.otp-inputs label').forEach(l=>l.classList.remove('error','success'));if(code==='2026'){qsa('.otp-inputs label').forEach(l=>l.classList.add('success'));localStorage.setItem('zetax_customer_session',JSON.stringify({email:'client@zetax.space',name:'عميل Zetax',company:'حساب شركة',loggedInAt:new Date().toISOString()}));status.textContent='تم التحقق بنجاح — جاري فتح لوحة العميل…';status.style.color='var(--green)';setTimeout(()=>location.href='/customer',620)}else{qsa('.otp-inputs label').forEach(l=>l.classList.add('error'));status.textContent='الرمز غير صحيح. استخدم 2026 للتجربة.';status.style.color='var(--red)'}});

  /* Existing session changes the login CTA to Customer Space */
  const session=JSON.parse(localStorage.getItem('zetax_customer_session')||'null');
  if(session&&qs('#openLogin'))qs('#openLogin').textContent=currentLang==='en'?'Customer Space':'لوحة العميل';
})();
